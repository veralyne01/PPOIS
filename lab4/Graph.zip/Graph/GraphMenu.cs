﻿using System;
using System.Collections.Generic;

namespace GeneralizedProgramming
{
    /// <summary>Консольное меню для демонстрации контейнера Graph&lt;string&gt;.</summary>
    public sealed class GraphMenu
    {
        private readonly Graph<string> _graph = new Graph<string>();

        public void Run()
        {
            while (true)
            {
                PrintMenu();
                string choice = Prompt("Выбор").Trim();
                if (choice == "0") return;

                try
                {
                    Execute(choice);
                }
                catch (GraphException ex)
                {
                    Console.WriteLine($"Ошибка: {ex.Message}");
                }
                Console.WriteLine();
            }
        }

        private void Execute(string choice)
        {
            switch (choice)
            {
                case "1": AddVertex(); break;
                case "2": AddEdge(); break;
                case "3": RemoveVertex(); break;
                case "4": RemoveEdge(); break;
                case "5": ContainsVertex(); break;
                case "6": ContainsEdge(); break;
                case "7": ShowCounts(); break;
                case "8": ShowVertexDegrees(); break;
                case "9": ShowEdgeDegree(); break;
                case "10": TraverseVertices(); break;
                case "11": TraverseEdges(); break;
                case "12": TraverseIncidentEdges(); break;
                case "13": TraverseAdjacentVertices(); break;
                case "14": RemoveVertexViaIterator(); break;
                case "15": RemoveEdgeViaIterator(); break;
                case "16": CopyAndCompare(); break;
                case "17": FillDemo(); break;
                case "18": Console.WriteLine(_graph); break;
                case "19": _graph.Clear(); Console.WriteLine("Граф очищен."); break;
                default: Console.WriteLine("Неизвестный пункт меню."); break;
            }
        }

        private static void PrintMenu()
        {
            Console.WriteLine("=== Directed graph (ordered edge lists) ===");
            Console.WriteLine(" 1. Add vertex");
            Console.WriteLine(" 2. Add edge");
            Console.WriteLine(" 3. Remove vertex (by id)");
            Console.WriteLine(" 4. Remove edge (by source and target id)");
            Console.WriteLine(" 5. Check if vertex exists");
            Console.WriteLine(" 6. Check if edge exists");
            Console.WriteLine(" 7. Vertex and edge counts, is graph empty");
            Console.WriteLine(" 8. Vertex degrees (in, out, total)");
            Console.WriteLine(" 9. Edge degree");
            Console.WriteLine("10. Traverse vertices with an iterator");
            Console.WriteLine("11. Traverse edges with an iterator");
            Console.WriteLine("12. Traverse edges incident to a vertex");
            Console.WriteLine("13. Traverse vertices adjacent to a vertex");
            Console.WriteLine("14. Remove vertex via iterator");
            Console.WriteLine("15. Remove edge via iterator");
            Console.WriteLine("16. Copy and compare graphs");
            Console.WriteLine("17. Add demo data");
            Console.WriteLine("18. Show graph");
            Console.WriteLine("19. Clear graph");
            Console.WriteLine(" 0. Exit");
        }

        // ---------- Простые операции ----------

        private void AddVertex()
        {
            string value = Prompt("Значение вершины");
            int id = _graph.AddVertex(value);
            Console.WriteLine($"Добавлена вершина {_graph.GetVertex(id)}.");
        }

        private void AddEdge()
        {
            int from = ReadInt("id начала ребра");
            int to = ReadInt("id конца ребра");
            _graph.AddEdge(from, to);
            Console.WriteLine($"Добавлено ребро {from} -> {to}.");
        }

        private void RemoveVertex()
        {
            int id = ReadInt("id вершины");
            _graph.RemoveVertex(id);
            Console.WriteLine($"Вершина {id} удалена вместе с инцидентными рёбрами.");
        }

        private void RemoveEdge()
        {
            int from = ReadInt("id начала ребра");
            int to = ReadInt("id конца ребра");
            _graph.RemoveEdge(from, to);
            Console.WriteLine($"Ребро {from} -> {to} удалено.");
        }

        private void ContainsVertex()
        {
            int id = ReadInt("id вершины");
            Console.WriteLine(_graph.ContainsVertex(id) ? "Вершина есть." : "Такой вершины нет.");
        }

        private void ContainsEdge()
        {
            int from = ReadInt("id начала ребра");
            int to = ReadInt("id конца ребра");
            Console.WriteLine(_graph.ContainsEdge(from, to) ? "Ребро есть." : "Такого ребра нет.");
        }

        private void ShowCounts()
        {
            Console.WriteLine($"Вершин: {_graph.VertexCount}, рёбер: {_graph.EdgeCount}, пустой: {(_graph.IsEmpty ? "да" : "нет")}.");
        }

        private void ShowVertexDegrees()
        {
            int id = ReadInt("id вершины");
            Console.WriteLine($"Входящая: {_graph.InDegree(id)}, исходящая: {_graph.OutDegree(id)}, общая: {_graph.Degree(id)}.");
        }

        private void ShowEdgeDegree()
        {
            int from = ReadInt("id начала ребра");
            int to = ReadInt("id конца ребра");
            Console.WriteLine($"Степень ребра {from} -> {to}: {_graph.EdgeDegree(from, to)}.");
        }

        // ---------- Обход итераторами ----------

        private void TraverseVertices()
        {
            if (ReadReverse())
                Traverse(_graph.GetConstReverseVertexIterator());
            else
                Traverse(_graph.GetConstVertexIterator());
        }

        private void TraverseEdges()
        {
            if (ReadReverse())
                Traverse(_graph.GetConstReverseEdgeIterator());
            else
                Traverse(_graph.GetConstEdgeIterator());
        }

        private void TraverseIncidentEdges()
        {
            int id = ReadInt("id вершины");
            if (ReadReverse())
                Traverse(_graph.GetConstReverseIncidentEdgeIterator(id));
            else
                Traverse(_graph.GetConstIncidentEdgeIterator(id));
        }

        private void TraverseAdjacentVertices()
        {
            int id = ReadInt("id вершины");
            if (ReadReverse())
                Traverse(_graph.GetConstReverseAdjacentVertexIterator(id));
            else
                Traverse(_graph.GetConstAdjacentVertexIterator(id));
        }

        /// <summary>Идёт итератором вперёд до конца, затем обратно (MovePrev), чтобы показать двунаправленность.</summary>
        private static void Traverse<TItem>(ConstGraphIterator<TItem> iterator)
        {
            var forward = new List<string>();
            GraphAlgorithms.ForEach(iterator, item => forward.Add(item?.ToString() ?? string.Empty));
            Console.WriteLine($"Вперёд (MoveNext): {JoinOrDash(forward)}");

            var backward = new List<string>();
            while (iterator.MovePrev())
                backward.Add(iterator.Current?.ToString() ?? string.Empty);
            Console.WriteLine($"Назад  (MovePrev): {JoinOrDash(backward)}");
        }

        // ---------- Удаление через итераторы ----------

        private void RemoveVertexViaIterator()
        {
            if (_graph.VertexCount == 0)
            {
                Console.WriteLine("В графе нет вершин.");
                return;
            }

            PrintNumbered(_graph.GetConstVertexIterator());
            int number = ReadInt("Номер вершины в списке");
            if (number < 1 || number > _graph.VertexCount)
            {
                Console.WriteLine("Номер вне диапазона.");
                return;
            }

            GraphIterator<Vertex<string>> iterator = _graph.GetVertexIterator();
            for (int i = 0; i < number; i++) iterator.MoveNext();

            Vertex<string> target = iterator.Current;
            _graph.RemoveVertex(iterator);
            Console.WriteLine($"Удалена вершина {target} (итератор после удаления недействителен).");
        }

        private void RemoveEdgeViaIterator()
        {
            if (_graph.EdgeCount == 0)
            {
                Console.WriteLine("В графе нет рёбер.");
                return;
            }

            PrintNumbered(_graph.GetConstEdgeIterator());
            int number = ReadInt("Номер ребра в списке");
            if (number < 1 || number > _graph.EdgeCount)
            {
                Console.WriteLine("Номер вне диапазона.");
                return;
            }

            GraphIterator<Edge<string>> iterator = _graph.GetEdgeIterator();
            for (int i = 0; i < number; i++) iterator.MoveNext();

            Edge<string> target = iterator.Current;
            _graph.RemoveEdge(iterator);
            Console.WriteLine($"Удалено ребро {target} (итератор после удаления недействителен).");
        }

        private static void PrintNumbered<TItem>(ConstGraphIterator<TItem> iterator)
        {
            int n = 0;
            GraphAlgorithms.ForEach(iterator, item => Console.WriteLine($"  {++n}. {item}"));
        }

        // ---------- Копирование и сравнение ----------

        private void CopyAndCompare()
        {
            Graph<string> copy = _graph.Clone();
            Console.WriteLine($"Клон создан. copy == graph: {copy == _graph}");

            copy.AddVertex("extra");
            Console.WriteLine("В копию добавлена вершина \"extra\":");
            Console.WriteLine($"  ==: {copy == _graph}, !=: {copy != _graph}");
            Console.WriteLine($"  <: {copy < _graph}, >: {copy > _graph}, <=: {copy <= _graph}, >=: {copy >= _graph}");

            var assigned = new Graph<string>();
            assigned.CopyFrom(copy);
            Console.WriteLine($"CopyFrom: assigned == copy: {assigned == copy}");
            Console.WriteLine("Копия:");
            Console.WriteLine(assigned);
        }

        private void FillDemo()
        {
            int a = _graph.AddVertex("A");
            int b = _graph.AddVertex("B");
            int c = _graph.AddVertex("C");
            int d = _graph.AddVertex("D");

            _graph.AddEdge(a, b);
            _graph.AddEdge(a, c);
            _graph.AddEdge(b, c);
            _graph.AddEdge(c, a);
            _graph.AddEdge(c, d);

            Console.WriteLine("Добавлено 4 вершины (A, B, C, D) и 5 рёбер.");
            Console.WriteLine(_graph);
        }

        // ---------- Ввод ----------

        private static string Prompt(string text)
        {
            Console.Write($"{text}: ");
            return Console.ReadLine() ?? "0";
        }

        private static int ReadInt(string text)
        {
            while (true)
            {
                string input = Prompt(text);
                if (int.TryParse(input, out int value)) return value;
                Console.WriteLine("Введите целое число.");
            }
        }

        private static bool ReadReverse()
        {
            while (true)
            {
                string input = Prompt("Направление (1 - прямой, 2 - обратный)").Trim();
                if (input == "1") return false;
                if (input == "2") return true;
                Console.WriteLine("Введите 1 или 2.");
            }
        }

        private static string JoinOrDash(List<string> items)
            => items.Count == 0 ? "-" : string.Join(", ", items);
    }
}