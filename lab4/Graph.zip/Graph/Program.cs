﻿using System;
using System.Text;

namespace GeneralizedProgramming
{
    internal static class Program
    {
        private static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            new GraphMenu().Run();
        }
    }
}